#!/bin/sh
rmmod ar6000
